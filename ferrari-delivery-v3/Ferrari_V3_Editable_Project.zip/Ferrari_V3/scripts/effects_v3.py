import io,json,math
import numpy as np
from PIL import Image

def add_burnout(movie,R,foreground=False):
 contacts=json.load(open(R/'wheel_contacts_projected.json'))
 # One shared, softly feathered smoke image; all particles retain real alpha.
 yy,xx=np.mgrid[-1:1:128j,-1:1:128j];rad=xx*xx+yy*yy
 cloud=np.exp(-rad*3.8)*np.clip(1-rad,0,1)**1.2
 cloud*=.75+.1*np.sin(xx*12+yy*7)+.09*np.cos(yy*15-xx*9)
 rgba=np.zeros((128,128,4),dtype=np.uint8);rgba[:,:,:3]=[188,204,219];rgba[:,:,3]=np.clip(cloud*125,0,255).astype(np.uint8)
 buf=io.BytesIO();Image.fromarray(rgba).save(buf,format='PNG',optimize=True);movie.images['Burnout_Soft_Smoke']=buf.getvalue()
 for side in ([1] if foreground else [0]):
  for j in range(10):
   birth=3.18+j*.043;idx=int(round(birth*60));x,y=contacts[idx][side];sp=movie.sprites.add(imageKey='Burnout_Soft_Smoke')
   for f in range(300):
    fr=sp.frames.add();age=f/60-birth
    if not 0<age<.66:continue
    q=age/.66;sz=20+56*q;fr.alpha=.48*math.sin(math.pi*q)**.75
    fr.layout.width=fr.layout.height=128;fr.transform.a=sz/128;fr.transform.d=sz*.65/128
    fr.transform.tx=x+(38+3*j)*q+8*math.sin(j*1.8)*q-sz/2;fr.transform.ty=y+3*q-4*math.cos(j*1.7)*q-sz*.65/2
 sp=movie.sprites.add(imageKey=('Burnout_Tiny_Sparks_Near.vector' if foreground else 'Burnout_Tiny_Sparks_Far.vector'))
 for f in range(300):
  fr=sp.frames.add(alpha=1);fr.layout.width=750;fr.layout.height=1624;fr.transform.a=fr.transform.d=1;t=f/60
  for side in ([1] if foreground else [0]):
   for j in range(9):
    birth=3.25+j*.045;age=t-birth
    if not 0<age<.2:continue
    q=age/.2;x,y=contacts[int(round(birth*60))][side];vx=26+11*math.sin(j*2.3);vy=-8-9*math.cos(j*1.6);px=x+vx*q;py=y+vy*q+11*q*q
    sh=fr.shapes.add(type=0);sh.shape.d=f'M{px:.2f} {py:.2f} L{px-vx*.1:.2f} {py-vy*.1:.2f}';sh.transform.a=sh.transform.d=1;sh.styles.stroke.r=1;sh.styles.stroke.g=.7;sh.styles.stroke.b=.3;sh.styles.stroke.a=.65*(1-q);sh.styles.strokeWidth=1.1;sh.styles.lineCap=1
 return 20

def add_lamp_flares(movie,R,rows):
 centers=json.load(open(R/'lamp_centers_projected.json'))
 yy,xx=np.mgrid[-1:1:80j,-1:1:160j]
 alpha=.45*np.exp(-xx*xx*18-yy*yy*4)+.8*np.exp(-np.abs(xx)*4-yy*yy*220)+.38*np.exp(-xx*xx*350-np.abs(yy)*5)
 rgba=np.zeros((80,160,4),dtype=np.uint8);rgba[:,:,:3]=[220,240,255];rgba[:,:,3]=np.clip(alpha*210,0,255).astype(np.uint8);buf=io.BytesIO();Image.fromarray(rgba).save(buf,format='PNG',optimize=True);movie.images['Headlight_Peak_Glint']=buf.getvalue()
 for side in range(2):
  sp=movie.sprites.add(imageKey='Headlight_Peak_Glint')
  for idx,r in enumerate(rows):
   fr=sp.frames.add()
   if r['pulse']<.001:continue
   w=26+8*r['pulse'];h=w*.52;x,y=centers[idx][side];fr.alpha=.85*r['pulse'];fr.layout.width=160;fr.layout.height=80;fr.transform.a=w/160;fr.transform.d=h/80;fr.transform.tx=x-w/2;fr.transform.ty=y-h/2
