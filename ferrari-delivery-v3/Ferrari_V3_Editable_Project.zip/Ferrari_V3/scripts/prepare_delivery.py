import json,shutil
from pathlib import Path
R=Path('/workspace/ferrari/v3');D=R/'deliverables';repo=Path('/workspace/ferrari/github-delivery');dest=repo/'ferrari-delivery-v3';dest.mkdir(exist_ok=True)
result=json.load(open(R/'COMPLETED.json'));assert result['status']=='complete'
files=list(result['files'])+['SHA256SUMS.txt','说明.txt','preview.html','svga.min.js','validation.json','player_validation.json','rgba_validation.json','rig_validation.json','motion_validation.json','revision_report.json','preview_metadata.json']
for n in files:shutil.copyfile(D/n,dest/n)
base='https://raw.githubusercontent.com/r1162495517-lang/12/main/ferrari-delivery-v3/'
rows=[('推荐：SVGA + 预览下载包','Ferrari_V3_Download.zip'),('透明 SVGA','Ferrari_Drift_V3_750x1624_60fps.svga'),('300 帧 RGBA PNG 序列','Ferrari_V3_RGBA_PNG_300frames.zip'),('可编辑 Blender 工程、FBX 和 maps','Ferrari_V3_Editable_Project.zip'),('MP4 观看预览','Ferrari_V3_preview.mp4')]
table='| 文件 | 下载 | 大小 |\n| --- | --- | --- |\n'+'\n'.join(f'| {label} | [{n}]({base+n}) | {(D/n).stat().st_size/1e6:.2f} MB |' for label,n in rows)
section='''## Ferrari V3：修订版透明礼物动效

750 × 1624 px · 60 FPS · 5 秒 · 300 帧。

本版保留 V2 的材质、视角和 S 弯路线，强化入场加速与转弯甩尾，提升两次闪灯亮度，加入车头到车尾的暖金流光。离场前后轮原地空转约 0.45 秒，伴随少量贴地烟雾与细小火花，再加速冲出画面；尾部光轨线性淡出。

Windows 用户点击下载包链接，将 ZIP 保存到电脑后解压。

'''+table+'''

SVGA 和 PNG 为真实透明背景；MP4 的棋盘格只用于观看。工程保留原始 91 个网格、710,996 个顶点、979,426 个多边形，未合并或降低精度。车轮滚动、前轮转向和卡钳层级已检查。

已通过 SVGA Web Player 2.3.2 加载、300 帧 RGBA 导出与尾部透明度检查；尚未在收件方实际移动 APP 的 SVGA SDK 上测试。

'''+f'[SHA-256 校验值]({base}SHA256SUMS.txt)\n'
readme=repo/'README.md';old=readme.read_text()
if '## Ferrari V3：' not in old:readme.write_text('# 12\n\n'+section+'\n---\n\n'+old.removeprefix('# 12\n\n'))
(R/'release_notes.md').write_text(section+'\n文件通过仓库直接下载链接提供。')
print(json.dumps({n:(dest/n).stat().st_size for n in files},ensure_ascii=False,indent=2))
