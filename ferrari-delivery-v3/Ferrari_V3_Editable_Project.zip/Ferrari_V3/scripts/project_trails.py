import bpy,json,math,numpy as np
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
R='/workspace/ferrari/v3';bpy.ops.wm.open_mainfile(filepath=R+'/Ferrari_Drift_V3.blend');s=bpy.context.scene;s.frame_set(116);s.render.resolution_percentage=100
tracks=json.load(open(R+'/tracks_3d.json'));out=[]
for tr in tracks:
 points=np.array(tr['points']);tangent=np.gradient(points[:,:2],axis=0);norm=np.stack([-tangent[:,1],tangent[:,0]],1);norm/=np.maximum(np.linalg.norm(norm,axis=1)[:,None],1e-8)
 bands=[]
 for width,alpha in [(.13,.03),(.075,.06),(.038,.14),(.021,.72)]:
  sides=[]
  for side in [1,-1]:
   xyz=points.copy();xyz[:,:2]+=norm*width*.5*side
   xy=[]
   for p in xyz:
    q=world_to_camera_view(s,s.camera,Vector(p));xy.append([round(q.x*750,4),round((1-q.y)*1624,4)])
   sides.append(xy)
  bands.append({'width':width,'alpha':alpha,'left':sides[0],'right':sides[1],'color':[.58,.8,1] if width>.021 else [.86,.94,1]})
 out.append({'side':tr['side'],'arc':tr['arc'],'length_by_frame':tr['length_by_frame'],'bands':bands})
json.dump(out,open(R+'/trails_projected.json','w'));print('Projected',len(out),'tracks with',len(out[0]['arc']),'samples')
contacts=[]
for f in range(1,301):
 s.frame_set(f);bpy.context.view_layer.update();motion=bpy.data.objects['RIG_Motion'];row=[]
 for side in [-1,1]:
  p=motion.matrix_world@Vector((side*.802,1.318,.12));q=world_to_camera_view(s,s.camera,p);row.append([q.x*750,(1-q.y)*1624])
 contacts.append(row)
json.dump(contacts,open(R+'/wheel_contacts_projected.json','w'))
lamps=[]
for f in range(1,301):
 s.frame_set(f);bpy.context.view_layer.update();body=bpy.data.objects['RIG_Body_Inertia'];row=[]
 for side in [-1,1]:
  p=body.matrix_world@Vector((side*.64,-2.015,.645));q=world_to_camera_view(s,s.camera,p);row.append([q.x*750,(1-q.y)*1624])
 lamps.append(row)
json.dump(lamps,open(R+'/lamp_centers_projected.json','w'))
