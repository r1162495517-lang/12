import bpy
R='/workspace/ferrari/v3';bpy.ops.wm.open_mainfile(filepath=R+'/Ferrari_Drift_V3.blend');s=bpy.context.scene;n=bpy.data.materials['HDM_06_007_07'].node_tree.nodes;p=n.get('Principled BSDF');p.inputs['Emission Color'].default_value=(1,.75,.4,1)
for z in n:
 if z.type=='MATH' and z.operation=='DIVIDE':z.inputs[1].default_value=.3
 if z.type=='MATH' and z.operation=='POWER':z.inputs[1].default_value=2.2
 if z.type=='MATH' and z.operation=='MULTIPLY' and not z.inputs[1].is_linked:z.inputs[1].default_value=1.25
bpy.ops.wm.save_as_mainfile(filepath=R+'/Ferrari_Drift_V3.blend');s.frame_set(152);bpy.data.collections['V3_Wheel_Path_Trails'].hide_render=True;s.cycles.samples=32;s.render.use_border=True;s.render.border_min_x=0;s.render.border_max_x=1;s.render.border_min_y=.3;s.render.border_max_y=.7;s.render.filepath=R+'/output/flow_refined.png';bpy.ops.render.render(write_still=True)
