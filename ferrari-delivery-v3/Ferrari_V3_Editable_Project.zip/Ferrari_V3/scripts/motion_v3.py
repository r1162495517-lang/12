import numpy as np,json
from scipy.interpolate import CubicHermiteSpline
from scipy.integrate import cumulative_trapezoid
R='/workspace/ferrari/v3'
spline=CubicHermiteSpline([0,.35,.65,.96,1.28,1.62],[[-4,35],[-12,17],[-10,8.7],[-2.4,3.6],[0,.9],[0,0]],[[-24,-65],[-4,-39],[15,-21],[10,-12],[0,-5.6],[0,0]])
ss=np.linspace(0,1.62,10001);pp=spline(ss);arc=np.r_[0,np.cumsum(np.linalg.norm(np.diff(pp,axis=0),axis=1))]
dt=1/600;t=np.arange(0,5+dt/2,dt);q=np.clip(t/1.72,0,1);progress=q*q*q*(10-15*q+6*q*q);param=np.interp(progress*arc[-1],arc,ss);pos=spline(param)
pos[t>=1.72]=0
u=np.maximum(t-3.6,0);pos[:,1]-=15.5*u**3
v=np.gradient(pos,dt,axis=0);a=np.gradient(v,dt,axis=0);speed=np.linalg.norm(v,axis=1)
heading=np.unwrap(np.arctan2(v[:,0],-v[:,1]));heading[speed<.001]=0
hd=np.gradient(heading,dt);slip=.29*np.tanh(hd/2.2)*np.clip(speed/6,0,1);slip[t>1.72]=0
anticipated=np.interp(t+.05,t,heading);target=anticipated+slip
yaw=np.zeros(len(t));yaw[0]=heading[0]
for i in range(1,len(t)):yaw[i]=yaw[i-1]+(target[i]-yaw[i-1])*(1-np.exp(-dt/.055))
settle=np.clip((1.94-t)/.22,0,1);settle=settle*settle*(3-2*settle);yaw=np.where(t>1.72,yaw*settle,yaw)
yd=np.gradient(yaw,dt);curvature=np.divide(v[:,0]*a[:,1]-v[:,1]*a[:,0],np.maximum(speed,1)**3)
steer=np.clip(np.arctan(2.72*curvature),-.28,.28)-np.clip(yaw-heading,-.35,.35)*.8;steer=np.interp(t+.08,t,steer)*np.clip(speed/3,0,1);steer[t>1.94]=0
roll=np.zeros(len(t));pitch=np.zeros(len(t))
for i in range(1,len(t)):
 rt=np.clip(-speed[i]*yd[i]*.0013,-.028,.028)
 pt=np.clip(np.dot(a[i],[np.sin(yaw[i]),-np.cos(yaw[i])])*.0005,-.022,.022)
 roll[i]=roll[i-1]+(rt-roll[i-1])*(1-np.exp(-dt/.12));pitch[i]=pitch[i-1]+(pt-pitch[i-1])*(1-np.exp(-dt/.13))
roll[(t>1.94)&(t<3.6)]=0;pitch[(t>1.94)&(t<3.15)]=0
burnq=np.clip((t-3.15)/.45,0,1);rpm=2*np.pi*8*(burnq**2*(3-2*burnq));rpm[t>3.6]*=np.exp(-(t[t>3.6]-3.6)/.12);extra=cumulative_trapezoid(rpm,t,initial=0)
pitch+=.008*np.sin(np.pi*burnq)**2
D=cumulative_trapezoid(speed,t,initial=0)
rows=[]
for f in range(300):
 j=f*10;ti=t[j];pulse=sum(np.sin(np.pi*(ti-start)/.26)**2 if start<=ti<=start+.26 else 0 for start in [2.12,2.62]);flowq=np.clip((ti-2.28)/.7,0,1);flowamp=np.sin(np.pi*flowq)**.6 if 0<flowq<1 else 0
 rows.append(dict(frame=f+1,time=float(ti),x=float(pos[j,0]),y=float(pos[j,1]),yaw=float(yaw[j]),heading=float(heading[j]),slip=float(yaw[j]-heading[j]),roll=float(roll[j]),pitch=float(pitch[j]),steer=float(steer[j]),distance=float(D[j]),speed=float(speed[j]),rear_spin=float(extra[j]),burnout=float(rpm[j]),pulse=float(pulse),flow_center=float(-2.65+5.3*flowq) if flowamp else -3,flow_amp=float(flowamp),effect_fade=min(1,max(0,(299-f)/29)) if f>=270 else 1))
json.dump(rows,open(R+'/motion_v3.json','w'),indent=2)
print('Path length',arc[-1],'speed max',max(r['speed'] for r in rows[:104]),'entry slip degrees max',max(abs(r['slip']) for r in rows[10:100])*180/np.pi,'burnout rotations',(np.interp(3.6,t,extra)-np.interp(3.15,t,extra))/(2*np.pi))
