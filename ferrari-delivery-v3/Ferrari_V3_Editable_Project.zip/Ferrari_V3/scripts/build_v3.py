import bpy,math,json,os,numpy as np
from mathutils import Vector
R='/workspace/ferrari/v3';bpy.ops.wm.open_mainfile(filepath='/workspace/ferrari/v2/Ferrari_Drift_V2.blend');s=bpy.context.scene;rows=json.load(open(R+'/motion_v3.json'));s.frame_set(116)
motion=bpy.data.objects['RIG_Motion'];body=bpy.data.objects['RIG_Body_Inertia'];motion.animation_data_clear();body.animation_data_clear()
for i in range(1,5):
 bpy.data.objects[f'RIG_Steer_{i}'].animation_data_clear();bpy.data.objects[f'RIG_Roll_{i}'].animation_data_clear()
radii=json.load(open('/workspace/ferrari/rig_report.json'))['wheel_radii']
lights=[bpy.data.objects[n] for n in ['Key_Softbox','Side_Strip','Rim_Softbox','Front_Fill']];positions={o.name:o.location.copy() for o in lights}
for o in lights:o.animation_data_clear()
led=bpy.data.materials['LED_Constant_With_Two_Soft_Pulses'];led.node_tree.animation_data_clear();em=next(n for n in led.node_tree.nodes if n.type=='EMISSION')
halo=bpy.data.materials['V2_Subtle_Headlight_Halo'];halo.node_tree.animation_data_clear();opacity=halo.node_tree.nodes['Pulse_Opacity'];he=next(n for n in halo.node_tree.nodes if n.type=='EMISSION');he.inputs['Strength'].default_value=3.5
for side in [-1,1]:bpy.data.objects[f'V2_Headlight_Halo_{side}'].scale=(1,1,1)
# A true surface-bound travelling highlight, evaluated in vehicle coordinates.
mat=bpy.data.materials['HDM_06_007_07'];n=mat.node_tree.nodes;l=mat.node_tree.links;p=n.get('Principled BSDF');coord=n.new('ShaderNodeTexCoord');coord.object=motion;sep=n.new('ShaderNodeSeparateXYZ');l.new(coord.outputs['Object'],sep.inputs[0]);center=n.new('ShaderNodeValue');center.name='V3_Flow_Center';amp=n.new('ShaderNodeValue');amp.name='V3_Flow_Amplitude'
def mathnode(op,a=None,b=None):
 z=n.new('ShaderNodeMath');z.operation=op
 if a is not None:l.new(a,z.inputs[0])
 if b is not None:z.inputs[1].default_value=b
 return z
sub=mathnode('SUBTRACT',sep.outputs['Y']);l.new(center.outputs[0],sub.inputs[1]);ab=mathnode('ABSOLUTE',sub.outputs[0]);div=mathnode('DIVIDE',ab.outputs[0],.43);inv=mathnode('SUBTRACT',None);inv.inputs[0].default_value=1;l.new(div.outputs[0],inv.inputs[1]);inv.use_clamp=True;pow=mathnode('POWER',inv.outputs[0],1.8);mult=mathnode('MULTIPLY',pow.outputs[0]);l.new(amp.outputs[0],mult.inputs[1]);gain=mathnode('MULTIPLY',mult.outputs[0],2.4);p.inputs['Emission Color'].default_value=(.55,.72,1,1);l.new(gain.outputs[0],p.inputs['Emission Strength'])
for r in rows:
 f=r['frame'];motion.location=(r['x'],r['y'],0);motion.rotation_euler=(0,0,r['yaw']);motion.keyframe_insert('location',frame=f);motion.keyframe_insert('rotation_euler',frame=f);body.rotation_euler=(r['pitch'],r['roll'],0);body.keyframe_insert('rotation_euler',frame=f)
 for i,rad in enumerate(radii,1):
  steer=bpy.data.objects[f'RIG_Steer_{i}'];spin=bpy.data.objects[f'RIG_Roll_{i}'];steer.rotation_euler.z=r['steer'] if i<=2 else 0;steer.keyframe_insert('rotation_euler',frame=f);spin.rotation_euler.x=r['distance']/rad+(r['rear_spin'] if i>2 else 0);spin.keyframe_insert('rotation_euler',frame=f)
 for o in lights:o.location=positions[o.name]+Vector((r['x'],r['y'],0));o.keyframe_insert('location',frame=f)
 em.inputs['Strength'].default_value=.65+29.35*r['pulse'];em.inputs['Strength'].keyframe_insert('default_value',frame=f);opacity.outputs[0].default_value=.022+.88*r['pulse'];opacity.outputs[0].keyframe_insert('default_value',frame=f)
 center.outputs[0].default_value=r['flow_center'];center.outputs[0].keyframe_insert('default_value',frame=f);amp.outputs[0].default_value=r['flow_amp'];amp.outputs[0].keyframe_insert('default_value',frame=f)
# Remove only added V2 trail curves, preserving every original model part.
coll=bpy.data.collections['V2_Wheel_Path_Trails']
for o in list(coll.objects):bpy.data.objects.remove(o,do_unlink=True)
coll.name='V3_Wheel_Path_Trails';coll.hide_render=False
T=np.array([r['time'] for r in rows]);tt=np.linspace(0,265/60,1061);xs=np.interp(tt,T,[r['x'] for r in rows]);ys=np.interp(tt,T,[r['y'] for r in rows]);yaw=np.interp(tt,T,[r['yaw'] for r in rows]);tracks=[]
for side in [-1,1]:
 x=xs+side*.802*np.cos(yaw)-1.318*np.sin(yaw);y=ys+side*.802*np.sin(yaw)+1.318*np.cos(yaw);pts=np.stack((x,y,np.full_like(x,.015)),1);lengths=np.r_[0,np.cumsum(np.linalg.norm(np.diff(pts,axis=0),axis=1))];keep=np.r_[True,np.diff(lengths)>1e-7];ll=lengths[keep];pp=pts[keep];arc=np.linspace(0,ll[-1],int(ll[-1]/.08)+2);samples=np.stack([np.interp(arc,ll,pp[:,j]) for j in range(3)],1);frame_lengths=np.interp(T,tt,lengths);tracks.append({'side':side,'points':samples.tolist(),'arc':arc.tolist(),'length_by_frame':frame_lengths.tolist()})
 for kind,width,alpha in [('Halo',.065,.075),('Core',.009,.58)]:
  curve=bpy.data.curves.new(f'V3_Trail_{side}_{kind}','CURVE');curve.dimensions='3D';curve.bevel_depth=width;curve.bevel_resolution=3;curve.bevel_factor_mapping_end='SPLINE';spl=curve.splines.new('POLY');spl.points.add(len(samples)-1)
  for pt,xyz in zip(spl.points,samples):pt.co=(*xyz,1)
  o=bpy.data.objects.new(curve.name,curve);coll.objects.link(o);m=bpy.data.materials.new(curve.name+'_Material');m.use_nodes=True;nn=m.node_tree.nodes;nn.clear();lk=m.node_tree.links;out=nn.new('ShaderNodeOutputMaterial');tr=nn.new('ShaderNodeBsdfTransparent');e=nn.new('ShaderNodeEmission');e.inputs[0].default_value=(.7,.88,1,1);e.inputs[1].default_value=1.4;mix=nn.new('ShaderNodeMixShader');lk.new(tr.outputs[0],mix.inputs[1]);lk.new(e.outputs[0],mix.inputs[2]);lk.new(mix.outputs[0],out.inputs[0]);curve.materials.append(m)
  for r,d in zip(rows,frame_lengths):curve.bevel_factor_end=max(1e-6,float(d/ll[-1]));curve.keyframe_insert('bevel_factor_end',frame=r['frame']);mix.inputs[0].default_value=alpha*r['effect_fade']*(r['frame']>1);mix.inputs[0].keyframe_insert('default_value',frame=r['frame'])
json.dump(tracks,open(R+'/tracks_3d.json','w'))
for act in bpy.data.actions:
 for fc in act.fcurves:
  for k in fc.keyframe_points:k.interpolation='LINEAR'
s.render.use_border=False;s.render.resolution_percentage=100;s.render.motion_blur_shutter=.32;s.frame_set(116);bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=R+'/Ferrari_Drift_V3.blend')
coll.hide_render=True;s.cycles.samples=32;s.render.use_border=True;s.render.border_min_x=0;s.render.border_max_x=1;s.render.border_min_y=.3;s.render.border_max_y=.7
for f in [136,152,166,205]:s.frame_set(f);s.render.filepath=R+f'/output/test_{f}.png';bpy.ops.render.render(write_still=True)
