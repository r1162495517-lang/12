import bpy,json,math
R='/workspace/ferrari/v3';bpy.ops.wm.open_mainfile(filepath=R+'/Ferrari_Drift_V3.blend');s=bpy.context.scene
source=json.load(open('/workspace/ferrari/inspection.json'))['objects'];issues=[]
for r in source:
 o=bpy.data.objects.get(r['name'])
 if not o:issues.append('Missing original object '+r['name']);continue
 if o.type=='MESH':
  if len(o.data.vertices)!=r['verts'] or len(o.data.polygons)!=r['faces']:issues.append('Topology changed '+o.name)
  if any(m.type=='DECIMATE' for m in o.modifiers):issues.append('Decimator '+o.name)
for i in range(1,5):
 for name in [f'HDM_06_007_brake_caliper_fr_{i:02d}',f'HDM_06_007_brake_black_fr_{i:02d}',f'HDM_06_007_brake_chrome_fr_{i:02d}']:
  assert bpy.data.objects[name].parent.name==f'RIG_Steer_{i}'
 for name in [f'HDM_06_007_rim_{i:02d}',f'HDM_06_007_tyre_{i:03d}',f'HDM_06_007_brake_disc_{i:02d}']:
  assert bpy.data.objects[name].parent.name==f'RIG_Roll_{i}'
scales=[]
for f in range(1,301):
 s.frame_set(f);scales.append(list(bpy.data.objects['RIG_Motion'].scale))
assert all(x==[1,1,1] for x in scales)
s.frame_set(180)
assert abs(bpy.data.objects['RIG_Steer_1'].rotation_euler.z)<1e-6
assert s.camera.data.type=='PERSP'
rows=json.load(open(R+'/motion_v3.json'));bright=[.65+29.35*r['pulse'] for r in rows];groups=[]
for i,v in enumerate(bright):
 if v>.65001:
  if not groups or i>groups[-1][-1]+1:groups.append([])
  groups[-1].append(i)
peaks=[max(g,key=lambda i:bright[i])+1 for g in groups]
assert len(peaks)==2,peaks
report={'original_objects_preserved':len(source),'mesh_objects':sum(o['type']=='MESH' for o in source),'vertices':sum(o['verts'] for o in source),'polygons':sum(o['faces'] for o in source),'topology_issues':issues,'animated_vehicle_scale':False,'camera':'fixed perspective','calipers_follow_steering_not_roll':True,'wheels_return_straight_during_hold':True,'light_pulse_peak_frames':peaks,'light_emission_min':min(bright),'light_emission_max':max(bright),'packed_images':len([i for i in bpy.data.images if i.packed_file])}
assert not issues,issues
report['front_wheel_centers_x']=[bpy.data.objects['RIG_Steer_'+str(i)].location.x for i in [1,2]]
report['rear_wheel_centers_x']=[bpy.data.objects['RIG_Steer_'+str(i)].location.x for i in [3,4]]
report['linear_effect_fade']=[r['effect_fade'] for r in rows[270:]]
assert all(abs(report['front_wheel_centers_x'][i])>.8 for i in [0,1])
assert all(abs(rows[i]['effect_fade']-(299-i)/29)<1e-7 for i in range(270,300))
report['rear_wheel_burnout_rotations']=((rows[216]['rear_spin']-rows[189]['rear_spin'])/(2*math.pi))
assert all(abs(r['x'])+abs(r['y'])<1e-8 for r in rows[189:217])
assert report['rear_wheel_burnout_rotations']>1.5
report['flow_travels_front_to_rear']=True
assert all(rows[i+1]['flow_center']>rows[i]['flow_center'] for i in range(138,178))
report['entry_speed_initial']=rows[1]['speed'];report['entry_speed_peak']=max(r['speed'] for r in rows[:104])
assert report['entry_speed_peak']>100*report['entry_speed_initial']
json.dump(report,open(R+'/rig_validation.json','w'),indent=2);print(report)
