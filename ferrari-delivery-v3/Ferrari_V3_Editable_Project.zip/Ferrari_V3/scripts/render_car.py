import bpy,json,os,math,time,shutil,sys
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
R='/workspace/ferrari/v3';out=R+'/output/car';os.makedirs(out,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=R+'/Ferrari_Drift_V3.blend');s=bpy.context.scene
bpy.data.collections['V3_Wheel_Path_Trails'].hide_render=True
s.render.resolution_percentage=100;s.render.use_border=True;s.render.use_crop_to_border=False;s.render.image_settings.compression=65
s.cycles.samples=40;s.cycles.adaptive_threshold=.055;s.cycles.adaptive_min_samples=8;s.render.threads_mode='FIXED';s.render.threads=3
meshes=[o for o in s.objects if o.type=='MESH' and not o.hide_render]
rows=json.load(open(R+'/motion_v3.json'));seen={};manifest=[]
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [];selected=set(map(int,args)) if args else None
for r in rows:
 f=r['frame']
 if selected and f not in selected:continue
 path=out+f'/frame_{f:04d}.png';s.frame_set(f);bpy.context.view_layer.update()
 points=[world_to_camera_view(s,s.camera,o.matrix_world@Vector(c)) for o in meshes for c in o.bound_box];front=[p for p in points if p.z>0]
 if front:
  x0=max(0,math.floor(min(p.x for p in front)*750)-20);x1=min(750,math.ceil(max(p.x for p in front)*750)+20);y0=max(0,math.floor(min(p.y for p in front)*1624)-20);y1=min(1624,math.ceil(max(p.y for p in front)*1624)+20)
 else:x0=x1=y0=y1=0
 blank=x0>=x1 or y0>=y1
 sig=tuple(round(r[k],7) for k in ['x','y','yaw','roll','pitch','steer','distance','pulse','rear_spin','flow_center','flow_amp']) if not blank else ('blank',)
 meta=dict(frame=f,border=[x0,y0,x1,y1],blank=blank)
 if blank:meta['alias']=0
 elif sig in seen:
  src=seen[sig];shutil.copyfile(out+f'/frame_{src:04d}.png',path);meta['alias']=src
 elif os.path.isfile(path):seen[sig]=f;meta['existing']=True
 else:
  s.render.border_min_x=x0/750;s.render.border_max_x=x1/750;s.render.border_min_y=y0/1624;s.render.border_max_y=y1/1624;s.render.filepath=path;t0=time.time();bpy.ops.render.render(write_still=True);meta['render_seconds']=round(time.time()-t0,2);seen[sig]=f
 manifest.append(meta);json.dump(manifest,open(R+('/render_test_manifest.json' if selected else '/render_manifest.json'),'w'),indent=2);print('PROGRESS',json.dumps(meta),flush=True)
