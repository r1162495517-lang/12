import json,subprocess,zipfile,shutil,hashlib
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np
R=Path('/workspace/ferrari/v2');D=R/'deliverables';O=R/'output'
manifest=json.load(open(R/'render_manifest.json'));assert len(manifest)==300
subprocess.run(['python',str(R/'scripts/package_v2.py')],check=True)
subprocess.run(['node',str(R/'scripts/export_player.cjs'),'--all'],check=True)
stats=[]
for i in range(1,301):
 p=O/'png'/f'frame_{i:04d}.png';im=Image.open(p);assert im.mode=='RGBA' and im.size==(750,1624)
 a=np.asarray(im)[:,:,3];stats.append({'frame':i,'alpha_min':int(a.min()),'alpha_max':int(a.max()),'alpha_sum':int(a.sum())});assert a[0,0]==0 and a[-1,-1]==0
assert stats[-1]['alpha_max']==0
assert all(stats[i]['alpha_sum']>=stats[i+1]['alpha_sum'] for i in range(270,299))
json.dump({'frame_count':300,'rgba':True,'dimensions':[750,1624],'last_frame_transparent':True,'tail_alpha_monotonic':True,'frames':stats},open(D/'rgba_validation.json','w'),indent=2)
with zipfile.ZipFile(D/'Ferrari_V2_RGBA_PNG_300frames.zip','w',compression=zipfile.ZIP_STORED) as z:
 for i in range(1,301):z.write(O/'png'/f'frame_{i:04d}.png',f'PNG/frame_{i:04d}.png')
bg=Image.new('RGB',(750,1624),'#171c24');draw=ImageDraw.Draw(bg)
for y in range(0,1624,32):
 for x in range(0,750,32):
  if (x//32+y//32)%2:draw.rectangle((x,y,x+31,y+31),fill='#222a35')
bg.save(O/'checker.png')
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-loop','1','-framerate','60','-i',str(O/'checker.png'),'-framerate','60','-start_number','1','-i',str(O/'png/frame_%04d.png'),'-filter_complex_threads','1','-filter_complex','[0:v][1:v]overlay=shortest=1:format=auto,format=yuv420p[v]','-map','[v]','-frames:v','300','-r','60','-c:v','libx264','-crf','18','-preset','fast','-threads','2','-movflags','+faststart',str(D/'Ferrari_V2_preview.mp4')],check=True)
meta=json.loads(subprocess.check_output(['ffprobe','-v','quiet','-show_streams','-show_format','-print_format','json',str(D/'Ferrari_V2_preview.mp4')]))
v=meta['streams'][0];assert v['width']==750 and v['height']==1624 and v['avg_frame_rate']=='60/1' and int(v['nb_frames'])==300
json.dump(meta,open(D/'preview_metadata.json','w'),indent=2)
for n in ['rig_validation.json','revision_report.json']:shutil.copyfile(R/n,D/n)
with zipfile.ZipFile(D/'Ferrari_V2_Download.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n in ['Ferrari_Drift_V2_750x1624_60fps.svga','Ferrari_V2_preview.mp4','preview.html','svga.min.js','说明.txt']:z.write(D/n,n)
with zipfile.ZipFile(D/'Ferrari_V2_Editable_Project.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.write(R/'Ferrari_Drift_V2.blend','Ferrari_V2/Ferrari_Drift_V2.blend')
 z.write('/workspace/ferrari/assets/HDM_06_007.fbx','Ferrari_V2/HDM_06_007.fbx')
 for p in Path('/workspace/ferrari/assets/maps').rglob('*'):
  if p.is_file():z.write(p,'Ferrari_V2/maps/'+p.name)
 for p in (R/'scripts').glob('*'):
  if p.is_file():z.write(p,'Ferrari_V2/scripts/'+p.name)
 for p in ['svga.proto','svga_pb2.py']:z.write('/workspace/ferrari/scripts/'+p,'Ferrari_V2/scripts/'+p)
 for n in ['motion_v2.json','tracks_3d.json','trails_projected.json','rig_validation.json','revision_report.json']:z.write(R/n,'Ferrari_V2/'+n)
 z.write(D/'说明.txt','Ferrari_V2/说明.txt')
for p in D.glob('*.zip'):
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
files={p.name:p.stat().st_size for p in D.iterdir() if p.suffix in ['.svga','.zip','.mp4'] and not p.name.startswith('test')}
assert all(n<100*1024*1024 for n in files.values()),files
(D/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256((D/n).read_bytes()).hexdigest()+'  '+n for n in sorted(files))+'\n')
json.dump({'status':'complete','files':files},open(R/'COMPLETED.json','w'),indent=2);print('COMPLETE',json.dumps(files),flush=True)
