import sys,io,json,zlib,hashlib,argparse,bisect
from pathlib import Path
sys.path[:0]=['/workspace/ferrari/scripts/vendor','/workspace/ferrari/scripts']
from PIL import Image
import numpy as np
import svga_pb2
R=Path('/workspace/ferrari/v2');D=R/'deliverables';D.mkdir(exist_ok=True)
ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');args=ap.parse_args()
rows=json.load(open(R/'motion_v2.json'));tracks=json.load(open(R/'trails_projected.json'))
manifest={r['frame']:r for r in json.load(open(R/'render_manifest.json'))}
def simplify(points,eps=.12):
 p=np.asarray(points)
 if len(p)<3:return p.tolist()
 v=p[-1]-p[0];den=np.dot(v,v)
 t=np.clip(((p-p[0])@v)/den,0,1) if den else np.zeros(len(p))
 d=np.linalg.norm(p-p[0]-t[:,None]*v,axis=1);i=int(d.argmax())
 if d[i]<=eps:return [p[0].tolist(),p[-1].tolist()]
 return simplify(p[:i+1],eps)[:-1]+simplify(p[i:],eps)
def prefix(points,arc,length):
 i=bisect.bisect_right(arc,length)
 if i==0:return [points[0]]
 if i==len(arc):return points
 frac=(length-arc[i-1])/(arc[i]-arc[i-1]);end=[points[i-1][k]+frac*(points[i][k]-points[i-1][k]) for k in range(2)]
 return points[:i]+[end]
m=svga_pb2.MovieEntity(version='2.0');m.params.viewBoxWidth=750;m.params.viewBoxHeight=1624;m.params.fps=60;m.params.frames=300
trail=m.sprites.add(imageKey='RearWheelTrails.vector')
for idx,row in enumerate(rows):
 fr=trail.frames.add(alpha=row['effect_fade']);fr.layout.width=750;fr.layout.height=1624;fr.transform.a=fr.transform.d=1
 for tr in tracks:
  length=tr['length_by_frame'][idx]
  if length<.01:continue
  for band in tr['bands']:
   left=simplify(prefix(band['left'],tr['arc'],length));right=simplify(prefix(band['right'],tr['arc'],length))
   pts=left+right[::-1]
   shape=fr.shapes.add(type=0);shape.shape.d='M'+' L'.join(f'{x:.2f} {y:.2f}' for x,y in pts)+' Z';shape.transform.a=shape.transform.d=1
   color=shape.styles.fill;color.r,color.g,color.b=band['color'];color.a=band['alpha']
blank=Image.new('RGBA',(750,1624));images={};hashes={};frame_items=[];stats=[]
for f in range(1,301):
 p=R/'output/car'/f'frame_{f:04d}.png'
 if p.exists():im=Image.open(p)
 elif manifest.get(f,{}).get('blank') or args.partial:im=blank
 else:raise RuntimeError(f'Missing nonblank frame {f}')
 assert im.mode=='RGBA' and im.size==(750,1624)
 px=np.array(im);px[px[:,:,3]==0,:3]=0;im=Image.fromarray(px);box=im.getchannel('A').getbbox()
 if box is None:frame_items.append(None);stats.append({'frame':f,'bbox':None});continue
 buf=io.BytesIO();im.crop(box).save(buf,format='PNG',optimize=True);data=buf.getvalue();digest=hashlib.sha256(data).hexdigest()
 key=hashes.get(digest)
 if key is None:key=f'car_{len(images):04d}';images[key]=data;hashes[digest]=key
 frame_items.append((key,box));stats.append({'frame':f,'bbox':box,'image':key})
m.images.update(images)
for key in images:
 sp=m.sprites.add(imageKey=key)
 for item in frame_items:
  fr=sp.frames.add()
  if item and item[0]==key:
   box=item[1];fr.alpha=1;fr.layout.width=box[2]-box[0];fr.layout.height=box[3]-box[1];fr.transform.a=fr.transform.d=1;fr.transform.tx=box[0];fr.transform.ty=box[1]
name='test_partial.svga' if args.partial else 'Ferrari_Drift_V2_750x1624_60fps.svga'
data=zlib.compress(m.SerializeToString(),9);(D/name).write_bytes(data)
check=svga_pb2.MovieEntity();check.ParseFromString(zlib.decompress(data));assert check.params.frames==300 and len(check.sprites[0].frames)==300
assert all(len(s.frames)==300 for s in check.sprites)
assert check.sprites[0].frames[-1].alpha==0
report=dict(format='SVGA 2.0',width=750,height=1624,fps=60,frames=300,duration_seconds=5,unique_images=len(images),bytes=len(data),decoded_image_memory_bytes=sum(Image.open(io.BytesIO(b)).width*Image.open(io.BytesIO(b)).height*4 for b in images.values()),trail_format='8 native vector ribbons projected from actual 3D rear wheel paths',partial=args.partial)
json.dump(report,open(D/('test_validation.json' if args.partial else 'validation.json'),'w'),indent=2)
json.dump(stats,open(D/('test_frame_bounds.json' if args.partial else 'frame_bounds.json'),'w'),indent=2)
print(json.dumps(report))
