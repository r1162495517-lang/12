const {chromium}=require('playwright'),fs=require('fs');
const R='/workspace/ferrari/v2',partial=process.argv.includes('--partial'),all=process.argv.includes('--all');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:1000,height:920},deviceScaleFactor:1});let errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:8766/preview.html'+(partial?'?file=test_partial.svga':''));await page.waitForFunction(()=>window.loaded,{timeout:120000});
 await page.evaluate(()=>{player.pauseAnimation();player.stepToFrame(115,false)});
 const meta=await page.evaluate(()=>({frames:svgaData.frames,fps:svgaData.FPS,size:svgaData.videoSize,sprites:svgaData.sprites.length}));
 const output=R+'/output/'+(all?'png':'player_samples');fs.mkdirSync(output,{recursive:true});let stats=[];
 const indices=all?Array.from({length:300},(_,i)=>i):[0,29,59,89,115,136,145,165,180,230,260,269,284,299];
 for(const idx of indices){
  const item=await page.evaluate(async idx=>{player.stepToFrame(idx,false);await new Promise(r=>requestAnimationFrame(r));const c=document.querySelector('#car canvas'),px=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let visible=0,alphaSum=0;for(let i=3;i<px.length;i+=4){if(px[i])visible++;alphaSum+=px[i]}return {png:c.toDataURL('image/png').split(',')[1],width:c.width,height:c.height,visible,alphaSum}},idx);
  fs.writeFileSync(output+`/frame_${String(idx+1).padStart(4,'0')}.png`,Buffer.from(item.png,'base64'));delete item.png;stats.push({frame:idx+1,...item});
  if(idx%30===0)console.log('EXPORTED',idx+1);
 }
 await page.evaluate(()=>{player.stepToFrame(115,false);document.querySelector('#scrub').value=115;document.querySelector('#time').textContent='1.92 s / 5.00 s'});await page.screenshot({path:R+'/output/player_check'+(partial?'_partial':'')+'.png'});
 meta.errors=errors;meta.frame_stats=stats;fs.writeFileSync(R+'/deliverables/player_validation'+(partial?'_partial':'')+'.json',JSON.stringify(meta,null,2));console.log(meta.frames,meta.fps,meta.size,errors);await browser.close();
 if(errors.length)process.exit(1);
})().catch(e=>{console.error(e);process.exit(1)});
