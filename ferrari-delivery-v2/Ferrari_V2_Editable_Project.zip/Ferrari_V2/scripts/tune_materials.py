import bpy,json
R='/workspace/ferrari/v2';bpy.ops.wm.open_mainfile(filepath=R+'/Ferrari_Drift_V2.blend');s=bpy.context.scene;s.frame_set(116)
for o in bpy.data.objects:
 if o.type=='LIGHT':o.data.specular_factor=.12
for sign in [-1,1]:
 o=bpy.data.objects[f'V2_Headlight_Halo_{sign}'];o.location=(sign*.64,-2.015,.645);o.scale=(.65,.65,.65)
for id in ['21','23']:
 m=bpy.data.materials['HDM_06_007_'+id];p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.075,.065,.052,1)
# Inspect opaque window borders versus transparent glass coverage.
o=bpy.data.objects['HDM_06_007_windows_001']
for idx in [0,1]:
 vs=[o.matrix_world@o.data.vertices[i].co for p in o.data.polygons if p.material_index==idx for i in p.vertices]
 print('Window slot',idx,[[round(min(v[j] for v in vs),3),round(max(v[j] for v in vs),3)] for j in range(3)],flush=True)
s.render.use_border=False;bpy.ops.wm.save_as_mainfile(filepath=R+'/Ferrari_Drift_V2.blend')
bpy.data.collections['V2_Wheel_Path_Trails'].hide_render=True;s.render.resolution_percentage=75;s.cycles.samples=24;s.render.use_border=True;s.render.border_min_x=0;s.render.border_max_x=1;s.render.border_min_y=.3;s.render.border_max_y=.7;s.render.filepath=R+'/output/hero_tune.png';bpy.ops.render.render(write_still=True)
