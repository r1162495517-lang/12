import bpy
R='/workspace/ferrari/v2';bpy.ops.wm.open_mainfile(filepath=R+'/Ferrari_Drift_V2.blend');s=bpy.context.scene;s.frame_set(116)
for o in bpy.data.objects:
 if o.type=='LIGHT':o.data.energy*=.08
s.world.node_tree.nodes.get('Background').inputs['Strength'].default_value=1.5;s.view_settings.exposure=.3
p=bpy.data.materials['HDM_06_007_07'].node_tree.nodes.get('Principled BSDF');p.inputs['Coat Weight'].default_value=.18;p.inputs['Specular IOR Level'].default_value=.25
bpy.ops.wm.save_as_mainfile(filepath=R+'/Ferrari_Drift_V2.blend')
bpy.data.collections['V2_Wheel_Path_Trails'].hide_render=True;s.render.resolution_percentage=75;s.cycles.samples=24;s.render.use_border=True;s.render.border_min_x=0;s.render.border_max_x=1;s.render.border_min_y=.3;s.render.border_max_y=.7;s.render.filepath=R+'/output/hero_soft.png';bpy.ops.render.render(write_still=True)
