import bpy
R='/workspace/ferrari/v2';bpy.ops.wm.open_mainfile(filepath=R+'/Ferrari_Drift_V2.blend');s=bpy.context.scene;s.frame_set(116)
for idx in ['12','06','26']:
 m=bpy.data.materials['HDM_06_007_'+idx];n=m.node_tree.nodes;l=m.node_tree.links
 out=next(x for x in n if x.type=='OUTPUT_MATERIAL');old=out.inputs['Surface'].links[0].from_socket
 geo=n.new('ShaderNodeNewGeometry');white=n.new('ShaderNodeBsdfTransparent');white.inputs[0].default_value=(1,1,1,1);mix=n.new('ShaderNodeMixShader')
 l.new(geo.outputs['Backfacing'],mix.inputs[0]);l.new(old,mix.inputs[1]);l.new(white.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],out.inputs[0])
 if idx=='12':
  tr=next(x for x in n if x.type=='BSDF_TRANSPARENT' and x!=white);tr.inputs[0].default_value=(.87,.91,.94,1)
p=bpy.data.materials['HDM_06_007_07'].node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.58,.014,.03,1);p.inputs['Coat Weight'].default_value=.22;p.inputs['Coat Roughness'].default_value=.19;p.inputs['Roughness'].default_value=.27
s.world.node_tree.nodes.get('Background').inputs['Strength'].default_value=2.0;s.view_settings.exposure=.4
light=bpy.data.lights.new('V2_Subtle_Cabin_Bounce','POINT');light.energy=3;light.shadow_soft_size=.35;light.color=(1,.92,.84);o=bpy.data.objects.new(light.name,light);s.collection.objects.link(o);o.parent=bpy.data.objects['RIG_Body_Inertia'];o.location=(0,.3,1.12)
s.render.use_border=False;bpy.ops.wm.save_as_mainfile(filepath=R+'/Ferrari_Drift_V2.blend')
bpy.data.collections['V2_Wheel_Path_Trails'].hide_render=True;s.render.resolution_percentage=100;s.cycles.samples=32;s.render.use_border=True;s.render.border_min_x=0;s.render.border_max_x=1;s.render.border_min_y=.3;s.render.border_max_y=.7;s.render.filepath=R+'/output/hero_finished.png';bpy.ops.render.render(write_still=True)
s.frame_set(137);s.render.filepath=R+'/output/pulse_finished.png';bpy.ops.render.render(write_still=True)
