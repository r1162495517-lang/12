import bpy,json
bpy.ops.wm.open_mainfile(filepath='/workspace/ferrari/Ferrari_Drift.blend');bpy.context.scene.frame_set(116)
for name in ['HDM_06_007_windows_001','HDM_06_007_headlights_glass_001','HDM_06_007_headlights_glass_002']:
 o=bpy.data.objects[name];print(name,[(m.name,sum(p.material_index==i for p in o.data.polygons)) for i,m in enumerate(o.data.materials)])
print('Lights',[(o.name,o.data.energy,o.data.size) for o in bpy.data.objects if o.type=='LIGHT'])
for i in range(1,5):
 o=bpy.data.objects[f'RIG_Steer_{i}'];print(o.name,list(o.location),list(o.rotation_euler))
print('curvemap',bpy.types.Curve.bl_rna.properties['bevel_factor_mapping_end'].enum_items.keys())
