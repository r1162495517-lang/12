import bpy, math, json, os
import numpy as np
from mathutils import Vector
R='/workspace/ferrari';V=R+'/v2'
bpy.ops.wm.open_mainfile(filepath=R+'/Ferrari_Drift.blend');s=bpy.context.scene;s.frame_set(116)
rows=json.load(open(R+'/motion.json'))
# Preserve all original meshes. Correct only front track width.
wheel_correction=[]
for i,dx in [(1,-.126),(2,.126)]:
 o=bpy.data.objects[f'RIG_Steer_{i}'];before=list(o.location);o.location.x+=dx
 wheel_correction.append({'wheel':i,'before':before,'after':list(o.location),'outward_shift_m':abs(dx)})
# Lower reference view, fixed perspective and unchanged vehicle scale.
cam=s.camera;cam.location=(9.2,-12.8,5.3);target=Vector((0,0,.55));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=43
# Controlled clearcoat, richer red instead of overexposed white softbox blocks.
p=bpy.data.materials['HDM_06_007_07'].node_tree.nodes.get('Principled BSDF')
for k,v in {'Base Color':(.42,.010,.024,1),'Metallic':.28,'Roughness':.3,'Coat Weight':.26,'Coat Roughness':.26,'Specular IOR Level':.32}.items():p.inputs[k].default_value=v
# Thin automotive glass: angle-dependent reflections over transmission, not opaque blue diffuse.
def thin_glass(m,transmission,reflection,roughness):
 m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links
 out=n.new('ShaderNodeOutputMaterial');tr=n.new('ShaderNodeBsdfTransparent');tr.inputs[0].default_value=(*transmission,1)
 gl=n.new('ShaderNodeBsdfGlossy');gl.inputs['Color'].default_value=(*reflection,1);gl.inputs['Roughness'].default_value=roughness
 fres=n.new('ShaderNodeFresnel');fres.inputs['IOR'].default_value=1.46
 mix=n.new('ShaderNodeMixShader');l.new(fres.outputs[0],mix.inputs[0]);l.new(tr.outputs[0],mix.inputs[1]);l.new(gl.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],out.inputs[0])
thin_glass(bpy.data.materials['HDM_06_007_12'],(.72,.77,.80),(.65,.7,.76),.10)
thin_glass(bpy.data.materials['HDM_06_007_06'],(.96,.98,1),(.65,.70,.76),.055)
lensmat=bpy.data.materials.get('HDM_06_007_26') or bpy.data.materials.new('HDM_06_007_26')
thin_glass(lensmat,(.94,.97,1),(.65,.70,.76),.045)
o=bpy.data.objects['HDM_06_007_headlights_glass_002'];o.data.materials.clear();o.data.materials.append(bpy.data.materials['HDM_06_007_26'])
# Subtle warm leather grain remains behind the clear glass.
leather=bpy.data.materials['HDM_06_007_21'];p=leather.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.028,.018,.012,1);p.inputs['Roughness'].default_value=.56
tex=leather.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(R+'/assets/maps/HDM_06_007_leather_01.jpg',check_existing=True)
bump=leather.node_tree.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.12;bump.inputs['Distance'].default_value=.0008;leather.node_tree.links.new(tex.outputs['Color'],bump.inputs['Height']);leather.node_tree.links.new(bump.outputs['Normal'],p.inputs['Normal'])
# Smooth, low-contrast studio environment gives reflections with no burned-out rectangular patches.
W,H=1024,512;u,v=np.meshgrid(np.arange(W)/W,np.arange(H)/H);img=np.zeros((H,W,4),dtype=np.float32)
base=.12+.10*np.exp(-((v-.5)/.28)**2);shade=base.copy()
for uc,vc,wu,wv,amp in [(.08,.53,.045,.20,.45),(.47,.52,.09,.23,.30),(.80,.57,.07,.18,.36)]:
 du=np.minimum(abs(u-uc),1-abs(u-uc));shade+=amp*np.exp(-(du/wu)**2-((v-vc)/wv)**2)
img[:,:,0]=shade*.96;img[:,:,1]=shade;img[:,:,2]=shade*1.04;img[:,:,3]=1
im=bpy.data.images.new('V2_Soft_Studio_Reflections',width=W,height=H,float_buffer=True);im.pixels.foreach_set(img.ravel());im.pack()
world=s.world;world.use_nodes=True;n=world.node_tree.nodes;n.clear();env=n.new('ShaderNodeTexEnvironment');env.image=im;bg=n.new('ShaderNodeBackground');bg.inputs['Strength'].default_value=.65;out=n.new('ShaderNodeOutputWorld');world.node_tree.links.new(env.outputs['Color'],bg.inputs['Color']);world.node_tree.links.new(bg.outputs[0],out.inputs[0])
settings={'Key_Softbox':((-3.5,-4,6),450,8,'DISK',8,(1,.94,.90)), 'Side_Strip':((5,1,5),380,6,'RECTANGLE',1.2,(.9,.95,1)), 'Rim_Softbox':((-5,5,5),500,5,'DISK',5,(1,.95,.91)), 'Front_Fill':((0,-7,3.5),170,6,'DISK',6,(.94,.97,1))}
for name,(pos,power,size,shape,sizey,color) in settings.items():
 o=bpy.data.objects[name];o.animation_data_clear();o.location=pos;o.rotation_euler=(Vector((0,0,.55))-o.location).to_track_quat('-Z','Y').to_euler();o.data.energy=power;o.data.shape=shape;o.data.size=size;o.data.size_y=sizey;o.data.color=color
 for r in rows:o.location=Vector(pos)+Vector((r['x'],r['y'],0));o.keyframe_insert('location',frame=r['frame'])
# Real emitting projector/LED meshes: low constant baseline plus two distinct pulses.
led=bpy.data.materials['LED_Constant_With_Two_Soft_Pulses'];led.node_tree.animation_data_clear();nodes=led.node_tree.nodes;nodes.clear();em=nodes.new('ShaderNodeEmission');em.inputs['Color'].default_value=(.64,.82,1,1);out=nodes.new('ShaderNodeOutputMaterial');led.node_tree.links.new(em.outputs[0],out.inputs[0])
# Small transparent radial glows are spatially attached to the lamps, never to the body silhouette.
def glow_material():
 m=bpy.data.materials.new('V2_Subtle_Headlight_Halo');m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links
 out=n.new('ShaderNodeOutputMaterial');uv=n.new('ShaderNodeTexCoord');dist=n.new('ShaderNodeVectorMath');dist.operation='DISTANCE';dist.inputs[1].default_value=(.5,.5,0);l.new(uv.outputs['UV'],dist.inputs[0])
 mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY';mul.inputs[1].default_value=2;l.new(dist.outputs['Value'],mul.inputs[0]);inv=n.new('ShaderNodeMath');inv.operation='SUBTRACT';inv.inputs[0].default_value=1;inv.use_clamp=True;l.new(mul.outputs[0],inv.inputs[1]);power=n.new('ShaderNodeMath');power.operation='POWER';power.inputs[1].default_value=2.5;l.new(inv.outputs[0],power.inputs[0])
 opacity=n.new('ShaderNodeValue');opacity.name='Pulse_Opacity';amp=n.new('ShaderNodeMath');amp.operation='MULTIPLY';l.new(power.outputs[0],amp.inputs[0]);l.new(opacity.outputs[0],amp.inputs[1]);tr=n.new('ShaderNodeBsdfTransparent');e=n.new('ShaderNodeEmission');e.inputs[0].default_value=(.55,.78,1,1);e.inputs[1].default_value=2.2;mix=n.new('ShaderNodeMixShader');l.new(amp.outputs[0],mix.inputs[0]);l.new(tr.outputs[0],mix.inputs[1]);l.new(e.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],out.inputs[0]);return m,opacity
halo,opacity=glow_material();body=bpy.data.objects['RIG_Body_Inertia']
for side in [-1,1]:
 bpy.ops.mesh.primitive_plane_add(size=.24);o=bpy.context.object;o.name=f'V2_Headlight_Halo_{side}';o.parent=body;o.location=(side*.63,-2.165,.65);o.data.materials.append(halo);o.visible_shadow=False
 c=o.constraints.new('TRACK_TO');c.target=cam;c.track_axis='TRACK_Z';c.up_axis='UP_Y'
for r in rows:
 t=r['time'];pulse=0
 for start in [2.15,2.62]:
  q=(t-start)/.25
  if 0<=q<=1:pulse+=math.sin(math.pi*q)**2
 em.inputs['Strength'].default_value=.65+7.35*pulse;em.inputs['Strength'].keyframe_insert('default_value',frame=r['frame'])
 opacity.outputs[0].default_value=.022+.42*pulse;opacity.outputs[0].keyframe_insert('default_value',frame=r['frame'])
 r['pulse']=pulse;r['effect_fade']=min(1,max(0,(300-r['frame'])/29)) if r['frame']>=271 else 1
# Actual rear-wheel contact paths, resampled uniformly in arc length for smooth trails.
T=np.array([r['time'] for r in rows]);tt=np.linspace(0,265/60,1061)
xs=np.interp(tt,T,[r['x'] for r in rows]);ys=np.interp(tt,T,[r['y'] for r in rows]);yaw=np.interp(tt,T,[r['yaw'] for r in rows]);tracks=[]
coll=bpy.data.collections.new('V2_Wheel_Path_Trails');s.collection.children.link(coll)
for side in [-1,1]:
 x=xs+side*.802*np.cos(yaw)-1.318*np.sin(yaw);y=ys+side*.802*np.sin(yaw)+1.318*np.cos(yaw);pts=np.stack((x,y,np.full_like(x,.015)),1)
 lengths=np.concatenate(([0],np.cumsum(np.linalg.norm(np.diff(pts,axis=0),axis=1))));keep=np.concatenate(([True],np.diff(lengths)>1e-7));ll=lengths[keep];pp=pts[keep]
 arc=np.linspace(0,ll[-1],int(ll[-1]/.08)+2);samples=np.stack([np.interp(arc,ll,pp[:,j]) for j in range(3)],1)
 frame_lengths=np.interp(T,tt,lengths);tracks.append({'side':side,'points':samples.tolist(),'arc':arc.tolist(),'length_by_frame':frame_lengths.tolist()})
 # Editable 3D source counterpart; delivery uses perspective-projected vector ribbons.
 for kind,width,alpha in [('Halo',.065,.075),('Core',.009,.58)]:
  curve=bpy.data.curves.new(f'V2_Trail_{side}_{kind}','CURVE');curve.dimensions='3D';curve.resolution_u=1;curve.bevel_depth=width;curve.bevel_resolution=3;curve.bevel_factor_mapping_end='SPLINE'
  spl=curve.splines.new('POLY');spl.points.add(len(samples)-1)
  for p,xyz in zip(spl.points,samples):p.co=(*xyz,1)
  o=bpy.data.objects.new(curve.name,curve);coll.objects.link(o)
  m=bpy.data.materials.new(curve.name+'_Material');m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links;out=n.new('ShaderNodeOutputMaterial');tr=n.new('ShaderNodeBsdfTransparent');e=n.new('ShaderNodeEmission');e.inputs[0].default_value=(.7,.88,1,1);e.inputs[1].default_value=1.4;mix=n.new('ShaderNodeMixShader');l.new(tr.outputs[0],mix.inputs[1]);l.new(e.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],out.inputs[0]);curve.materials.append(m)
  for r,d in zip(rows,frame_lengths):
   curve.bevel_factor_end=max(1e-6,float(d/ll[-1]));curve.keyframe_insert('bevel_factor_end',frame=r['frame']);mix.inputs[0].default_value=alpha*r['effect_fade']*(r['frame']>1);mix.inputs[0].keyframe_insert('default_value',frame=r['frame'])
json.dump(tracks,open(V+'/tracks_3d.json','w'));json.dump(rows,open(V+'/motion_v2.json','w'),indent=2)
for action in bpy.data.actions:
 for fc in action.fcurves:
  for k in fc.keyframe_points:k.interpolation='LINEAR'
s.view_settings.view_transform='AgX';s.view_settings.look='AgX - Medium High Contrast';s.view_settings.exposure=0
s.cycles.samples=40;s.cycles.adaptive_min_samples=8;s.cycles.adaptive_threshold=.055;s.cycles.max_bounces=6;s.cycles.transparent_max_bounces=12;s.cycles.use_denoising=True;s.cycles.seed=7;s.cycles.use_animated_seed=False
s.render.resolution_percentage=100;s.render.use_border=False;s.render.film_transparent=True;s.render.image_settings.color_mode='RGBA';s.render.use_motion_blur=True;s.render.motion_blur_shutter=.24
s.render.filepath=V+'/output/car/frame_';s.frame_set(116);bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=V+'/Ferrari_Drift_V2.blend')
json.dump({'front_wheel_correction':wheel_correction,'camera_location':list(cam.location),'camera_target':list(target),'azimuth_degrees':math.degrees(math.atan2(9.2,12.8)),'elevation_degrees':math.degrees(math.atan2(4.75,math.hypot(9.2,12.8))),'lens':43,'fade_start_frame':271,'fade_end_frame':300},open(V+'/revision_report.json','w'),indent=2)
# Material/view validation frame, trails excluded so car quality is easy to inspect.
coll.hide_render=True;s.render.resolution_percentage=75;s.cycles.samples=32;s.render.use_border=True;s.render.use_crop_to_border=False;s.render.border_min_x=0;s.render.border_max_x=1;s.render.border_min_y=.3;s.render.border_max_y=.7
s.render.filepath=V+'/output/hero_test.png';bpy.ops.render.render(write_still=True)
