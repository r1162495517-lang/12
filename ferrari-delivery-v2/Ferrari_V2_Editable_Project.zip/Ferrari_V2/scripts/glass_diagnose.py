import bpy
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='/workspace/ferrari/v2/Ferrari_Drift_V2.blend');s=bpy.context.scene;s.frame_set(116);dg=bpy.context.evaluated_depsgraph_get()
for target in [Vector((0,-.3,1.12)),Vector((.4,-.25,1.10)),Vector((.8,.4,1.04))]:
 start=s.camera.location.copy();direction=(target-start).normalized();print('RAY TARGET',list(target))
 for j in range(12):
  ok,p,n,idx,o,m=s.ray_cast(dg,start,direction)
  if not ok:break
  mat=o.data.polygons[idx].material_index if o.type=='MESH' and idx<len(o.data.polygons) else -1
  print(o.name,idx,mat,o.data.materials[mat].name if mat>=0 and len(o.data.materials)>mat else '',[round(v,3) for v in p]);start=p+direction*.001
