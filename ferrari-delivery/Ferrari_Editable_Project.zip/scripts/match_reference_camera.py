import bpy,math,json
from mathutils import Vector
R='/workspace/ferrari';bpy.ops.wm.open_mainfile(filepath=R+'/Ferrari_Drift.blend');s=bpy.context.scene
# Match the reference's more frontal front-left view; portrait framing stays centered.
s.camera.location=(8.1,-10.8,6.1);target=Vector((0,0,.45));s.camera.rotation_euler=(target-s.camera.location).to_track_quat('-Z','Y').to_euler();s.camera.data.lens=37
s.frame_set(116);s.render.resolution_percentage=100;s.cycles.samples=32;s.cycles.adaptive_min_samples=8;s.cycles.adaptive_threshold=.07
s.render.filepath=R+'/output/reference_camera_hero.png';s.render.use_border=True;s.render.use_crop_to_border=False;s.render.border_min_x=0;s.render.border_max_x=1;s.render.border_min_y=.3;s.render.border_max_y=.65
bpy.ops.wm.save_as_mainfile(filepath=R+'/Ferrari_Drift.blend')
json.dump({'reference_time_seconds':1.5,'camera_azimuth_degrees':math.degrees(math.atan2(8.1,10.8)),'camera_elevation_degrees':math.degrees(math.atan2(6.1-.45,math.hypot(8.1,10.8))),'lens_mm':37,'camera_type':'PERSP','reference_camera_estimate':'Visual landmark estimate, not original scene camera metadata'},open(R+'/camera_match.json','w'),indent=2)
bpy.ops.render.render(write_still=True)
