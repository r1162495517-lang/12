import bpy,json
from mathutils import Vector
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath='/workspace/ferrari/assets/HDM_06_007.fbx')
report=[]
for o in bpy.data.objects:
 b=[o.matrix_world@Vector(v) for v in o.bound_box]
 report.append(dict(name=o.name,type=o.type,loc=list(o.location),rot=list(o.rotation_euler),scale=list(o.scale),verts=len(o.data.vertices) if o.type=='MESH' else 0,faces=len(o.data.polygons) if o.type=='MESH' else 0,bounds=[[min(v[i] for v in b),max(v[i] for v in b)] for i in range(3)],materials=[m.name if m else None for m in o.data.materials] if o.type=='MESH' else []))
materials=[]
for m in bpy.data.materials:
 materials.append(dict(name=m.name,color=list(m.diffuse_color),nodes=[dict(name=n.name,type=n.type,image=n.image.filepath if n.type=='TEX_IMAGE' and n.image else None) for n in m.node_tree.nodes] if m.use_nodes else []))
json.dump(dict(objects=report,materials=materials),open('/workspace/ferrari/inspection.json','w'),indent=2)
bpy.ops.wm.save_as_mainfile(filepath='/workspace/ferrari/imported.blend')
print('INSPECT',len(report),'objects',len(materials),'materials')
