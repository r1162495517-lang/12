import bpy, math,json,os
from mathutils import Vector,Matrix
ROOT='/workspace/ferrari'
bpy.ops.wm.open_mainfile(filepath=ROOT+'/imported.blend')
sc=bpy.context.scene
# Keep all source meshes, topology, normals and UVs. Only repair FBX shader translation.
for m in bpy.data.materials:
 p=m.node_tree.nodes.get('Principled BSDF')
 if not p: continue
 p.inputs['Metallic'].default_value=0
 p.inputs['Roughness'].default_value=.35
 p.inputs['Alpha'].default_value=1
 for l in list(m.node_tree.links):
  if l.to_node==p and l.to_socket.name=='Normal': m.node_tree.links.remove(l)
 idx=m.name.split('_')[-1]
 if idx in ['00','15','16','24','25','30','32','34','41']:
  p.inputs['Metallic'].default_value=.92;p.inputs['Roughness'].default_value=.18
  p.inputs['Base Color'].default_value=(.48,.51,.55,1) if idx!='32' else (.24,.26,.29,1)
 if idx in ['01','02','03','04','05','08','10','21','23','35','37']:
  p.inputs['Base Color'].default_value=(.012,.015,.018,1);p.inputs['Roughness'].default_value=.42
 if idx=='07':
  p.inputs['Base Color'].default_value=(.46,.009,.021,1);p.inputs['Metallic'].default_value=.38;p.inputs['Roughness'].default_value=.22
  p.inputs['Coat Weight'].default_value=.65;p.inputs['Coat Roughness'].default_value=.16
 if idx=='36':
  for l in list(m.node_tree.links):
   if l.to_node==p:m.node_tree.links.remove(l)
  p.inputs['Base Color'].default_value=(.018,.021,.024,1);p.inputs['Roughness'].default_value=.65
  tex=next((n for n in m.node_tree.nodes if n.type=='TEX_IMAGE' and n.image and 'sidewall' in n.image.name),None)
  if tex:
   bump=m.node_tree.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.14;bump.inputs['Distance'].default_value=.001
   m.node_tree.links.new(tex.outputs['Color'],bump.inputs['Height']);m.node_tree.links.new(bump.outputs['Normal'],p.inputs['Normal'])
 if idx=='29':p.inputs['Metallic'].default_value=.8;p.inputs['Roughness'].default_value=.34
 if idx in ['06','26','14']:
  p.inputs['Base Color'].default_value=(.84,.91,1,1);p.inputs['Roughness'].default_value=.07;p.inputs['Transmission Weight'].default_value=1
  p.inputs['IOR'].default_value=1.46
 if idx=='12':
  p.inputs['Base Color'].default_value=(.12,.16,.20,1);p.inputs['Roughness'].default_value=.12;p.inputs['Transmission Weight'].default_value=.80
 if idx=='13':
  p.inputs['Base Color'].default_value=(.008,.012,.017,1);p.inputs['Roughness'].default_value=.2;p.inputs['Coat Weight'].default_value=.5
 if idx in ['09','20']:
  p.inputs['Base Color'].default_value=(.3,.002,.004,1);p.inputs['Roughness'].default_value=.22
  p.inputs['Emission Color'].default_value=(1,.008,.004,1);p.inputs['Emission Strength'].default_value=.22
 if idx=='18':p.inputs['Roughness'].default_value=.23
# All original object datablocks preserved. Reparent with world transforms intact.
source=[o for o in bpy.data.objects if o.type=='MESH']
original_counts=(sum(len(o.data.vertices) for o in source),sum(len(o.data.polygons) for o in source))
def empty(name,loc=(0,0,0),parent=None):
 o=bpy.data.objects.new(name,None);sc.collection.objects.link(o);o.location=loc;o.parent=parent;return o
def parent_keep(o,p):
 mat=o.matrix_world.copy();o.parent=p;o.matrix_world=mat
motion=empty('RIG_Motion');body=empty('RIG_Body_Inertia',parent=motion)
for o in source:parent_keep(o,body)
bpy.context.view_layer.update()
wheels=[]
for i in range(1,5):
 tire=bpy.data.objects[f'HDM_06_007_tyre_{i:03d}'];vs=[tire.matrix_world@v.co for v in tire.data.vertices]
 center=Vector([(max(v[j] for v in vs)+min(v[j] for v in vs))/2 for j in range(3)])
 radius=(max(v.z for v in vs)-min(v.z for v in vs))/2
 steer=empty(f'RIG_Steer_{i}',center,motion);spin=empty(f'RIG_Roll_{i}',parent=steer)
 bpy.context.view_layer.update()
 for o in source:
  if o.name in [f'HDM_06_007_tyre_{i:03d}',f'HDM_06_007_rim_{i:02d}',f'HDM_06_007_brake_disc_{i:02d}',f'HDM_06_007_wheel_nuts_fr_{i:02d}']:parent_keep(o,spin)
  elif o.name in [f'HDM_06_007_brake_caliper_fr_{i:02d}',f'HDM_06_007_brake_black_fr_{i:02d}',f'HDM_06_007_brake_chrome_fr_{i:02d}']:parent_keep(o,steer)
 wheels.append((steer,spin,radius,center))
# Dedicated light material, rather than flashing chrome badges or body paint.
lightmat=bpy.data.materials.new('LED_Constant_With_Two_Soft_Pulses');lightmat.use_nodes=True
p=lightmat.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.8,.9,1,1);p.inputs['Roughness'].default_value=.2
p.inputs['Emission Color'].default_value=(.75,.87,1,1);p.inputs['Emission Strength'].default_value=1.3
for n in ['headlights_chrome_003','headlights_chrome_005','headlights_glass_002']:
 o=bpy.data.objects['HDM_06_007_'+n];o.data.materials.clear();o.data.materials.append(lightmat)
# Camera: fixed perspective, no animated scaling.
bpy.ops.object.camera_add(location=(7.3,-9.8,6.6));cam=bpy.context.object;cam.name='Camera_Fixed_Perspective'
target=Vector((0,0,.62));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=65;cam.data.sensor_width=36;cam.data.clip_end=500;sc.camera=cam
# Broad studio sources, stable illumination; highlights change with geometry orientation.
world=bpy.data.worlds.new('Studio_Environment');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.35,.4,.5,1);world.node_tree.nodes['Background'].inputs[1].default_value=.32;sc.world=world

def area(name,pos,power,size,color,scale_y=1):
 data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='RECTANGLE';data.size=size;data.size_y=size*scale_y;data.color=color
 o=bpy.data.objects.new(name,data);sc.collection.objects.link(o);o.location=pos;o.rotation_euler=(Vector((0,0,.5))-o.location).to_track_quat('-Z','Y').to_euler();return o
area('Key_Softbox',(1,-4,8),1800,7,(1,.92,.86),.7)
area('Side_Strip',(6,1,4.5),1300,6,(.83,.91,1),.25)
area('Rim_Softbox',(-4,5,6),2200,6,(1,.9,.84),.5)
area('Front_Fill',(-2,-6,3),550,5,(.9,.95,1),.6)
sc.render.engine='CYCLES';sc.cycles.device='CPU';sc.cycles.samples=24;sc.cycles.use_denoising=True;sc.cycles.use_adaptive_sampling=True;sc.cycles.adaptive_threshold=.06
sc.cycles.max_bounces=6;sc.cycles.transmission_bounces=5;sc.cycles.transparent_max_bounces=6
sc.render.resolution_x=750;sc.render.resolution_y=1624;sc.render.resolution_percentage=50;sc.render.film_transparent=True
sc.render.image_settings.file_format='PNG';sc.render.image_settings.color_mode='RGBA';sc.render.image_settings.color_depth='8';sc.render.image_settings.compression=30
sc.render.fps=60;sc.frame_start=1;sc.frame_end=300
sc.view_settings.view_transform='AgX';sc.view_settings.look='AgX - Medium High Contrast';sc.view_settings.exposure=.3
sc.render.use_persistent_data=True
sc.frame_set(100);sc.render.filepath=ROOT+'/output/hero_test.png'
bpy.ops.wm.save_as_mainfile(filepath=ROOT+'/studio.blend')
assert original_counts==(sum(len(o.data.vertices) for o in source),sum(len(o.data.polygons) for o in source))
json.dump({'source_mesh_objects':len(source),'vertices':original_counts[0],'polygons':original_counts[1],'wheel_centers':[list(w[3]) for w in wheels],'wheel_radii':[w[2] for w in wheels]},open(ROOT+'/rig_report.json','w'),indent=2)
bpy.ops.render.render(write_still=True)
