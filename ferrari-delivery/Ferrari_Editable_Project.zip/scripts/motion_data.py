import numpy as np,json
from scipy.interpolate import CubicHermiteSpline
from scipy.integrate import cumulative_trapezoid
# Metres and seconds; fixed camera and unit vehicle scale.
times=[0,.35,.65,.96,1.28,1.62]
xy=[[-4,35],[-12,17],[-10,8.7],[-2.4,3.6],[0,.9],[0,0]]
vel=[[-24,-65],[-4,-39],[15,-21],[10,-12],[0,-5.6],[0,0]]
spline=CubicHermiteSpline(times,xy,vel)
dt=1/600;t=np.arange(0,5+dt/2,dt)
pos=np.zeros((len(t),2));v=pos.copy();a=pos.copy()
mask=t<1.62
pos[mask]=spline(t[mask]);v[mask]=spline(t[mask],1);a[mask]=spline(t[mask],2)
# Jerk-continuous takeoff, accelerating toward the lens / lower left.
u=np.maximum(t-3.55,0)
pos[:,1]+= -11*u**3
v[:,1]+= -33*u**2
a[:,1]+= -66*u
speed=np.linalg.norm(v,axis=1)
heading=np.arctan2(v[:,0],-v[:,1]);heading[(speed<.005)]=0
heading=np.unwrap(heading)
# Chassis yaw lags the path direction. Small, damped rear slip then correction.
yaw=np.zeros(len(t));yaw[0]=heading[0]
for i in range(1,len(t)):
 target=heading[i]+np.radians(8)*np.exp(-((t[i]-.97)/.14)**2)
 yaw[i]=yaw[i-1]+(target-yaw[i-1])*(1-np.exp(-dt/.065))
# Smoothly finish settling before the stable hero hold.
fade=np.clip((1.92-t)/.3,0,1);fade=fade*fade*(3-2*fade)
yaw=np.where(t>1.62,yaw*fade,yaw)
yawdot=np.gradient(yaw,dt)
curvature=np.divide(v[:,0]*a[:,1]-v[:,1]*a[:,0],np.maximum(speed,1)**3)
steer=np.clip(np.arctan(2.72*curvature),-.22,.22)-np.clip(yaw-heading,-.18,.18)*.7
# Steering sees upcoming path curvature before the body rotates.
steer=np.interp(t+.07,t,steer);steer*=np.clip(speed/3,0,1)
roll=np.zeros_like(t);pitch=np.zeros_like(t)
for i in range(1,len(t)):
 ar=np.clip(-speed[i]*yawdot[i]*.0015,-.018,.018)
 ap=np.clip(np.dot(a[i],np.array([np.sin(yaw[i]),-np.cos(yaw[i])]))*.0005,-.016,.016)
 roll[i]=roll[i-1]+(ar-roll[i-1])*(1-np.exp(-dt/.13))
 pitch[i]=pitch[i-1]+(ap-pitch[i-1])*(1-np.exp(-dt/.16))
for arr in [roll,pitch]: arr*=np.where(t>1.62,fade,1)
distance=cumulative_trapezoid(speed,t,initial=0)
# Two restrained pulses, baseline remains lit. Smooth in/out, no hard flashes.
light=np.full(len(t),1.3)
for begin in [2.13,2.55]:
 q=(t-begin)/.22
 light+=np.where((q>=0)&(q<=1),3.7*np.sin(np.pi*np.clip(q,0,1))**2,0)
rows=[]
for f in range(300):
 ti=f/60; j=int(round(ti/dt))
 rows.append(dict(frame=f+1,time=ti,x=float(pos[j,0]),y=float(pos[j,1]),yaw=float(yaw[j]),roll=float(roll[j]),pitch=float(pitch[j]),steer=float(steer[j]),distance=float(distance[j]),speed=float(speed[j]),light=float(light[j])))
json.dump(rows,open('/workspace/ferrari/motion.json','w'),indent=2)
