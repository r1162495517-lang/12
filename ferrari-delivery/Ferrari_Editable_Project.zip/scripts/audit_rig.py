import bpy,json,math
R='/workspace/ferrari';bpy.ops.wm.open_mainfile(filepath=R+'/Ferrari_Drift.blend');s=bpy.context.scene
source=json.load(open(R+'/inspection.json'))['objects'];issues=[]
for r in source:
 o=bpy.data.objects.get(r['name'])
 if not o:issues.append('Missing original object '+r['name']);continue
 if o.type=='MESH':
  if len(o.data.vertices)!=r['verts'] or len(o.data.polygons)!=r['faces']:issues.append('Topology changed '+o.name)
  if any(m.type=='DECIMATE' for m in o.modifiers):issues.append('Decimator '+o.name)
for i in range(1,5):
 for name in [f'HDM_06_007_brake_caliper_fr_{i:02d}',f'HDM_06_007_brake_black_fr_{i:02d}',f'HDM_06_007_brake_chrome_fr_{i:02d}']:
  assert bpy.data.objects[name].parent.name==f'RIG_Steer_{i}'
 for name in [f'HDM_06_007_rim_{i:02d}',f'HDM_06_007_tyre_{i:03d}',f'HDM_06_007_brake_disc_{i:02d}']:
  assert bpy.data.objects[name].parent.name==f'RIG_Roll_{i}'
scales=[]
for f in range(1,301):
 s.frame_set(f);scales.append(list(bpy.data.objects['RIG_Motion'].scale))
assert all(x==[1,1,1] for x in scales)
s.frame_set(180)
assert abs(bpy.data.objects['RIG_Steer_1'].rotation_euler.z)<1e-6
assert s.camera.data.type=='PERSP'
rows=json.load(open(R+'/motion.json'));bright=[r['light'] for r in rows];peaks=[i+1 for i in range(1,299) if bright[i]>bright[i-1] and bright[i]>bright[i+1]]
assert len(peaks)==2,peaks
report={'original_objects_preserved':len(source),'mesh_objects':sum(o['type']=='MESH' for o in source),'vertices':sum(o['verts'] for o in source),'polygons':sum(o['faces'] for o in source),'topology_issues':issues,'animated_vehicle_scale':False,'camera':'fixed perspective','calipers_follow_steering_not_roll':True,'wheels_return_straight_during_hold':True,'light_pulse_peak_frames':peaks,'light_emission_min':min(bright),'light_emission_max':max(bright),'packed_images':len([i for i in bpy.data.images if i.packed_file])}
assert not issues,issues
json.dump(report,open(R+'/rig_validation.json','w'),indent=2);print(report)
