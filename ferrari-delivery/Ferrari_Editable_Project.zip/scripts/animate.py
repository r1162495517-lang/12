import bpy,math,json
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
R='/workspace/ferrari'
bpy.ops.wm.open_mainfile(filepath=R+'/studio.blend');s=bpy.context.scene
s.camera.location=(9.5,-9.5,5.6);s.camera.rotation_euler=(Vector((0,0,.7))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.camera.data.lens=40
motion=bpy.data.objects['RIG_Motion'];body=bpy.data.objects['RIG_Body_Inertia']
lights=[o for o in bpy.data.objects if o.type=='LIGHT'];light_positions={o.name:o.location.copy() for o in lights}
p=bpy.data.materials['LED_Constant_With_Two_Soft_Pulses'].node_tree.nodes.get('Principled BSDF')
rows=json.load(open(R+'/motion.json'));radii=json.load(open(R+'/rig_report.json'))['wheel_radii']
for r in rows:
 f=r['frame'];motion.location=(r['x'],r['y'],0);motion.rotation_euler=(0,0,r['yaw']);motion.keyframe_insert('location',frame=f);motion.keyframe_insert('rotation_euler',frame=f)
 body.rotation_euler=(r['pitch'],r['roll'],0);body.keyframe_insert('rotation_euler',frame=f)
 for i,rad in enumerate(radii,1):
  steer=bpy.data.objects[f'RIG_Steer_{i}'];spin=bpy.data.objects[f'RIG_Roll_{i}']
  steer.rotation_euler.z=r['steer'] if i<=2 else 0;steer.keyframe_insert('rotation_euler',frame=f)
  spin.rotation_euler.x=r['distance']/rad;spin.keyframe_insert('rotation_euler',frame=f)
 p.inputs['Emission Strength'].default_value=r['light'];p.inputs['Emission Strength'].keyframe_insert('default_value',frame=f)
 for o in lights:
  o.location=light_positions[o.name]+Vector((r['x'],r['y'],0));o.keyframe_insert('location',frame=f)
for act in bpy.data.actions:
 for curve in act.fcurves:
  for k in curve.keyframe_points:k.interpolation='LINEAR'
s.render.resolution_percentage=100;s.cycles.samples=24;s.cycles.adaptive_threshold=.09;s.cycles.seed=7;s.cycles.use_animated_seed=False
s.render.use_motion_blur=True;s.render.motion_blur_shutter=.24
s.render.filepath=R+'/output/png/frame_'
s.frame_set(115)
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=R+'/Ferrari_Drift.blend')
# Numerical framing audit (full bounding boxes are conservative).
projections=[]
for f in [1,16,25,40,58,78,98,115,214,232,244,256,268,280,300]:
 s.frame_set(f);bpy.context.view_layer.update();o=bpy.data.objects['HDM_06_007_carpaint_01'];pts=[world_to_camera_view(s,s.camera,o.matrix_world@Vector(c)) for c in o.bound_box]
 projections.append({'frame':f,'center':[round(world_to_camera_view(s,s.camera,motion.location).x*750),round((1-world_to_camera_view(s,s.camera,motion.location).y)*1624)],'bounds':[round(min(p.x for p in pts)*750),round(min(1-p.y for p in pts)*1624),round(max(p.x for p in pts)*750),round(max(1-p.y for p in pts)*1624)]})
json.dump(projections,open(R+'/framing.json','w'),indent=2);print('FRAMING',projections,flush=True)
s.render.resolution_percentage=50;s.cycles.samples=16
for f in [58]:
 s.frame_set(f);s.render.filepath=R+f'/output/check_{f:03d}.png';bpy.ops.render.render(write_still=True)
